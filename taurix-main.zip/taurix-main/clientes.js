/* ═══════════════════════════════════════════════════════
   TUGESTOR · clientes.js
   Módulo completo de gestión de clientes
   ═══════════════════════════════════════════════════════ */

import { supabase } from "./supabase.js";
import { SESSION, CLIENTES, setClientes, toast, openModal, closeModal } from "./utils.js";

export async function loadClientes() {
  const { data, error } = await supabase.from("clientes")
    .select("*").eq("user_id", SESSION.user.id).order("nombre");
  if (error) { console.error("loadClientes:", error.message); return []; }
  return data || [];
}

export async function refreshClientes() {
  const lista = await loadClientes();
  setClientes(lista);
  renderClientesTable(lista);
  populateClienteSelect();
  const countEl = document.getElementById("clientesCount");
  if (countEl) countEl.textContent = `${lista.length} cliente${lista.length!==1?"s":""} registrados`;
}

export function renderClientesTable(list) {
  const tbody = document.getElementById("clientesBody");
  if (!tbody) return;
  if (!list.length) {
    tbody.innerHTML = `<tr class="dt-empty"><td colspan="9">Sin clientes. Añade tu primer cliente.</td></tr>`;
    return;
  }
  tbody.innerHTML = list.map(c => `
    <tr>
      <td><strong>${c.nombre||"—"}</strong>${c.razon_social?`<br><span style="font-size:11px;color:var(--t3)">${c.razon_social}</span>`:""}</td>
      <td class="mono">${c.nif||"—"}</td>
      <td style="font-size:13px">${c.email||"—"}</td>
      <td style="font-size:13px">${c.telefono||"—"}</td>
      <td>${c.pais||"ES"}</td>
      <td><span class="badge ${c.tipo==="empresa"?"b-income":"b-ic"}">${c.tipo==="empresa"?"Empresa":"Particular"}</span></td>
      <td style="text-align:center">—</td>
      <td class="mono fw7">—</td>
      <td>
        <div class="tbl-act">
          <button class="ta-btn" onclick="window._verCliente('${c.id}')" title="Ver historial">📊</button>
          <button class="ta-btn" onclick="window._editCliente('${c.id}')">✏️</button>
          <button class="ta-btn ta-del" onclick="window._delCliente('${c.id}')">🗑️</button>
        </div>
      </td>
    </tr>
  `).join("");
}

export function populateClienteSelect() {
  const sel = document.getElementById("nfClienteSelect");
  if (!sel) return;
  sel.innerHTML = `<option value="">— Nuevo cliente / Sin asignar —</option>`;
  CLIENTES.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = `${c.nombre}${c.nif?" · "+c.nif:""}`;
    sel.appendChild(opt);
  });
}

export function showNuevoClienteModal(prefill = {}) {
  openModal(`
    <div class="modal">
      <div class="modal-hd">
        <span class="modal-title">👤 ${prefill.id?"Editar":"Nuevo"} cliente</span>
        <button class="modal-x" onclick="window._cm()">×</button>
      </div>
      <div class="modal-bd">
        <p class="modal-note">Los clientes se asocian automáticamente a las facturas para agilizar la facturación.</p>
        <div class="modal-grid2">
          <div class="modal-field"><label>Nombre *</label><input autocomplete="off" id="mc_nombre" value="${prefill.nombre||""}" placeholder="Nombre o razón social"/></div>
          <div class="modal-field"><label>Tipo</label>
            <select id="mc_tipo">
              <option value="empresa"    ${prefill.tipo==="empresa"?"selected":""}>Empresa / Autónomo</option>
              <option value="particular" ${prefill.tipo==="particular"?"selected":""}>Particular</option>
            </select>
          </div>
        </div>
        <div class="modal-grid2">
          <div class="modal-field"><label>NIF / CIF / VAT</label><input autocomplete="off" id="mc_nif" value="${prefill.nif||""}" placeholder="Ej: B12345678"/></div>
          <div class="modal-field"><label>País</label>
            <select id="mc_pais">
              ${["ES:🇪🇸 España","DE:🇩🇪 Alemania","FR:🇫🇷 Francia","IT:🇮🇹 Italia","PT:🇵🇹 Portugal","US:🇺🇸 EE.UU.","GB:🇬🇧 Reino Unido","MX:🇲🇽 México","OTHER:🌍 Otro"]
                .map(x=>{const[v,l]=x.split(":");return `<option value="${v}" ${(prefill.pais||"ES")===v?"selected":""}>${l}</option>`;}).join("")}
            </select>
          </div>
        </div>
        <div class="modal-grid2">
          <div class="modal-field"><label>Email</label><input autocomplete="off" type="email" id="mc_email" value="${prefill.email||""}" placeholder="cliente@empresa.com"/></div>
          <div class="modal-field"><label>Teléfono</label><input autocomplete="off" id="mc_tel" value="${prefill.telefono||""}" placeholder="+34 600 000 000"/></div>
        </div>
        <div class="modal-field"><label>Dirección</label><input autocomplete="off" id="mc_dir" value="${prefill.direccion||""}" placeholder="Calle, número, ciudad, CP"/></div>
      </div>
      <div class="modal-ft">
        <button class="btn-modal-cancel" onclick="window._cm()">Cancelar</button>
        <button class="btn-modal-save" id="mc_save">Guardar cliente</button>
      </div>
    </div>
  `);
  document.getElementById("mc_save").onclick = async () => {
    const nombre = document.getElementById("mc_nombre").value.trim();
    if (!nombre) { toast("El nombre es obligatorio","error"); return; }
    const payload = {
      user_id: SESSION.user.id,
      nombre, tipo: document.getElementById("mc_tipo").value,
      nif:      document.getElementById("mc_nif").value.trim(),
      pais:     document.getElementById("mc_pais").value,
      email:    document.getElementById("mc_email").value.trim(),
      telefono: document.getElementById("mc_tel").value.trim(),
      direccion:document.getElementById("mc_dir").value.trim(),
    };
    let err;
    if (prefill.id) {
      ({ error: err } = await supabase.from("clientes").update(payload).eq("id", prefill.id));
      if (err) { toast("Error actualizando: "+err.message,"error"); return; }
      toast("Cliente actualizado","success");
    } else {
      ({ error: err } = await supabase.from("clientes").insert(payload));
      if (err) { toast("Error creando: "+err.message,"error"); return; }
      toast("Cliente creado","success");
    }
    closeModal();
    await refreshClientes();
  };
}

window._editCliente = async id => {
  const c = CLIENTES.find(x=>x.id===id);
  if (c) showNuevoClienteModal(c);
};
window._delCliente = id => {
  openModal(`
    <div class="modal">
      <div class="modal-hd"><span class="modal-title">Eliminar cliente</span><button class="modal-x" onclick="window._cm()">×</button></div>
      <div class="modal-bd">
        <p class="modal-warn">⚠️ ¿Eliminar este cliente? Las facturas asociadas no se eliminarán pero perderán la referencia de cliente.</p>
      </div>
      <div class="modal-ft">
        <button class="btn-modal-cancel" onclick="window._cm()">Cancelar</button>
        <button class="btn-modal-danger" id="_delOk">Sí, eliminar</button>
      </div>
    </div>
  `);
  document.getElementById("_delOk").onclick = async () => {
    const { error } = await supabase.from("clientes").delete().eq("id",id);
    if (error) { toast("Error eliminando: "+error.message,"error"); closeModal(); return; }
    closeModal(); toast("Cliente eliminado","success");
    await refreshClientes();
  };
};

window._verCliente = async (id) => {
  const c = CLIENTES.find(x => x.id === id);
  if (!c) return;

  // Cargar facturas del cliente
  const { data: facturas } = await supabase.from("facturas")
    .select("numero_factura, fecha, base, iva, estado, cobrada, concepto")
    .eq("user_id", SESSION.user.id).eq("cliente_id", id)
    .order("fecha", { ascending: false }).limit(20);

  const total = (facturas || []).reduce((a, f) => a + f.base + f.base*(f.iva||0)/100, 0);
  const cobrado = (facturas || []).filter(f=>f.cobrada).reduce((a, f) => a + f.base + f.base*(f.iva||0)/100, 0);
  const pendiente = total - cobrado;

  openModal(`
    <div class="modal" style="max-width:700px">
      <div class="modal-hd">
        <span class="modal-title">📊 ${c.nombre} — Historial</span>
        <button class="modal-x" onclick="window._cm()">×</button>
      </div>
      <div class="modal-bd">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-bottom:20px">
          <div style="background:var(--bg2);padding:12px;border-radius:10px;text-align:center">
            <div style="font-size:10px;color:var(--t3);text-transform:uppercase;font-weight:700">Facturas</div>
            <div style="font-size:24px;font-weight:800">${(facturas||[]).length}</div>
          </div>
          <div style="background:var(--bg2);padding:12px;border-radius:10px;text-align:center">
            <div style="font-size:10px;color:var(--t3);text-transform:uppercase;font-weight:700">Total facturado</div>
            <div style="font-size:16px;font-weight:800;font-family:monospace;color:var(--accent)">${fmt(total)}</div>
          </div>
          <div style="background:#f0fdf4;padding:12px;border-radius:10px;text-align:center">
            <div style="font-size:10px;color:var(--t3);text-transform:uppercase;font-weight:700">Cobrado</div>
            <div style="font-size:16px;font-weight:800;font-family:monospace;color:#059669">${fmt(cobrado)}</div>
          </div>
          <div style="background:${pendiente > 0 ? "#fef2f2" : "var(--bg2)"};padding:12px;border-radius:10px;text-align:center">
            <div style="font-size:10px;color:var(--t3);text-transform:uppercase;font-weight:700">Pendiente</div>
            <div style="font-size:16px;font-weight:800;font-family:monospace;color:${pendiente > 0 ? "#dc2626" : "var(--t3)"}">${fmt(pendiente)}</div>
          </div>
        </div>
        <div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--t3);margin-bottom:8px">Datos del cliente</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;font-size:13px">
          <div><span style="color:var(--t3)">NIF:</span> <strong>${c.nif||"—"}</strong></div>
          <div><span style="color:var(--t3)">Email:</span> <strong>${c.email||"—"}</strong></div>
          <div><span style="color:var(--t3)">Teléfono:</span> <strong>${c.telefono||"—"}</strong></div>
          <div><span style="color:var(--t3)">País:</span> <strong>${c.pais||"ES"}</strong></div>
          <div style="grid-column:1/-1"><span style="color:var(--t3)">Dirección:</span> <strong>${c.direccion||"—"}</strong></div>
        </div>
        <div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--t3);margin-bottom:8px">Últimas facturas</div>
        <table class="data-table">
          <thead><tr><th>Fecha</th><th>Nº Factura</th><th>Concepto</th><th>Total</th><th>Estado</th></tr></thead>
          <tbody>
            ${(facturas||[]).map(f => `<tr>
              <td class="mono" style="font-size:12px">${fmtDate(f.fecha)}</td>
              <td><span class="badge b-income mono" style="font-size:11px">${f.numero_factura||"Borrador"}</span></td>
              <td style="font-size:12px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${f.concepto||"—"}</td>
              <td class="mono fw7">${fmt(f.base+f.base*(f.iva||0)/100)}</td>
              <td><span class="badge ${f.cobrada?"b-cobrada":"b-pendiente"}">${f.cobrada?"✅":"⏳"}</span></td>
            </tr>`).join("") || `<tr class="dt-empty"><td colspan="5">Sin facturas registradas</td></tr>`}
          </tbody>
        </table>
      </div>
      <div class="modal-ft">
        <button class="btn-modal-cancel" onclick="window._cm()">Cerrar</button>
        <button class="btn-modal-save" onclick="window._cm();window._editCliente('${c.id}')">✏️ Editar cliente</button>
      </div>
    </div>`);
};

export function initClientesView() {
  document.getElementById("nuevoClienteBtn")?.addEventListener("click", () => showNuevoClienteModal());
  document.getElementById("clienteSearch")?.addEventListener("input", e => {
    const q = e.target.value.toLowerCase();
    renderClientesTable(CLIENTES.filter(c =>
      (c.nombre||"").toLowerCase().includes(q) ||
      (c.nif||"").toLowerCase().includes(q) ||
      (c.email||"").toLowerCase().includes(q)
    ));
  });
}
